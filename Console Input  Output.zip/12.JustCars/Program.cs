﻿/*
Problem 12.** Falling Rocks
• Implement the "Falling Rocks" game in the text console. 
◦ A small dwarf stays at the bottom of the screen and can move left and right (by the arrows keys).

◦ A number of rocks of different sizes and forms constantly fall down and you need to avoid a crash.

◦ Rocks are the symbols  ^, @, *, &, +, %, $, #, !, ., ;, -  distributed with appropriate density. The dwarf is  (O) .

• Ensure a constant game speed by  Thread.Sleep(150) .
• Implement collision detection and scoring system
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

struct Object 
{
    public int x;
    public int y;
    public string c;
    public ConsoleColor color;
}

class Program
{
    static void PrintPosition(int x,int y,string c,ConsoleColor color = ConsoleColor.Gray)
    {
        Console.SetCursorPosition(x,y);
        Console.ForegroundColor = color;
        Console.Write(c);
    }


    static void Main(string[] args)
    {
        Random randomGenerator = new Random();
        char[] chArrayOfSymbols=new char[12] {'^', '@', '*', '&', '+', '%', '$', '#', '!', '.', ';', '-'};
        int intPlayFieldWidht = 20;
        int intScore = 0;
        int intBest = 0;
        Console.BackgroundColor = ConsoleColor.Black;
        int intLivesCount = 5;
        Console.BufferHeight = Console.WindowHeight=15;
        Console.BufferWidth = Console.WindowWidth=45;

        //The "(0)" object
        Object userObject = new Object();
        userObject.x = (intPlayFieldWidht/2);
        userObject.y = Console.WindowHeight - 1;
        userObject.c = "(0)";
        userObject.color = ConsoleColor.Yellow;

        List<Object> objects =new List<Object>();
       
        string strEndOfGame="GAME OVER !!!";
        
        
        while (true)
        {
            bool boolHitted = false;
            bool blBonus = false;
           
            //Creating a bonus symbol
            if ((randomGenerator.Next(0, 100)) < 2)
            {
                Object newObject = new Object();
                newObject.x = randomGenerator.Next(0, intPlayFieldWidht);
                newObject.y = 0;
                newObject.color = ConsoleColor.Blue;
                newObject.c = ":";
                objects.Add(newObject);
            }
            //Creating a random symbol
            else
            {
                Object newObject = new Object();
                newObject.x = randomGenerator.Next(0, intPlayFieldWidht);
                newObject.y = 0;
                newObject.color = (ConsoleColor)(randomGenerator.Next(Enum.GetNames(typeof(ConsoleColor)).Length));
                newObject.c = chArrayOfSymbols[randomGenerator.Next(0, chArrayOfSymbols.Length)].ToString();
                objects.Add(newObject);
            }



            //if a key is pressed
            while (Console.KeyAvailable)
            {
                //takes the pressed key
                ConsoleKeyInfo pressedkey = Console.ReadKey(true);

                if (pressedkey.Key == ConsoleKey.LeftArrow)
                {
                    if ((userObject.x + userObject.c.Length) - 1 >= 3)
                        userObject.x--;
                }
                else if (pressedkey.Key == ConsoleKey.RightArrow)
                {
                    if ((userObject.x + userObject.c.Length) + 1 < intPlayFieldWidht+1)
                        userObject.x++;
                }
            }//End of "while" a key is pressed

            List<Object> newList = new List<Object>();
            for (int i = 0; i < objects.Count; i++)
            {
                Object oldObject = objects[i];
                Object newObject = new Object();
                newObject.x = oldObject.x;
                newObject.y = oldObject.y + 1;
                newObject.c = oldObject.c;
                newObject.color = oldObject.color;
                if (newObject.c == ":" && newObject.x >= userObject.x && newObject.x <= userObject.x+2 && newObject.y == userObject.y)
                {
                    blBonus = true;
                    intLivesCount++;
                }
                else if (newObject.c != ":" && newObject.x >= userObject.x && newObject.x <= userObject.x + 2 && newObject.y == userObject.y)
                {
                    intLivesCount -= 1;
                    boolHitted = true;
                    if (intLivesCount <= 0)
                    {
                        PrintPosition((Console.WindowWidth / 2) - (strEndOfGame.Length / 2), Console.WindowHeight / 2, strEndOfGame, ConsoleColor.White);
                       if (intScore > intBest)
                            intBest = intScore;
                        PrintPosition(21, 5, "Best Score : " + intBest.ToString(), ConsoleColor.Red);
                        Console.ReadLine();
                        return;
                    }
                }
                if (newObject.y < Console.WindowHeight)
                {
                    newList.Add(newObject);
                }

            }

            

            objects = newList;
           

            Console.Clear();

            PrintPosition(21, 2, "Resting lives : " + intLivesCount.ToString(), ConsoleColor.Red);
            PrintPosition(21, 3, "Score : " + intScore.ToString(), ConsoleColor.Red);
            PrintPosition(21, 5, "Best Score : " + intBest.ToString(), ConsoleColor.Red);

            foreach (Object objectItem in objects)
            {
                PrintPosition(objectItem.x, objectItem.y, objectItem.c, objectItem.color);
            }

            

            if (boolHitted)
            {
                objects.Clear();
                PrintPosition(userObject.x, userObject.y, "XXX", ConsoleColor.Red);
            }
            else if(blBonus)
            {
                PrintPosition(userObject.x, userObject.y, "000", ConsoleColor.Blue);
            }

            else
            {
                PrintPosition(userObject.x, userObject.y, userObject.c, userObject.color);
            }

            intScore++;
            Thread.Sleep(150);
        }
    }
}

