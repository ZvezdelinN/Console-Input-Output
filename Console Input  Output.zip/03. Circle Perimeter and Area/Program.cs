﻿/*
Problem 3. Circle Perimeter and Area
• Write a program that reads the radius  r  of a circle and prints its perimeter and area formatted with  2  digits after the decimal point.

Examples:


r       perimeter       area

2       12.57           12.57 
3.5     21.99           38.48 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Circle_Perimeter_and_Area
{
    class Program
    {
        static void Main(string[] args)
        {
            double dblRadius;
            double dblPerimetar;
            double dblArea;

            Console.Write("Please enter radius : ");
            dblRadius = double.Parse(Console.ReadLine());

            dblPerimetar =2 * Math.PI * dblRadius;
            dblArea = Math.PI * Math.Pow(dblRadius,2);

            Console.WriteLine("The circle with radius {0} has perimetar = {1:F2} and area = {2:F2}",dblRadius,dblPerimetar,dblArea);
        }
    }
}
