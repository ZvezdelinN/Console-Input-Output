﻿/*
Problem 2. Print Company Information
• A company has name, address, phone number, fax number, web site and manager. The manager has first name, last name, age and a phone number.
• Write a program that reads the information about a company and its manager and prints it back on the console.

Example input:


program                 user

Company name:           Telerik Academy 
Company address:        231 Al. Malinov, Sofia 
Phone number:           +359 888 55 55 555 
Fax number:             2 
Web site:               http://telerikacademy.com/ 
Manager first name:     Nikolay 
Manager last name:      Kostov 
Manager age:            25 
Manager phone:          +359 2 981 981 

Example output:
 
Telerik Academy
Address: 231 Al. Malinov, Sofia
Tel. +359 888 55 55 555
Fax: (no fax)
Web site: http://telerikacademy.com/
Manager: Nikolay Kostov (age: 25, tel. +359 2 981 981)  
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02.Print_Company_Information
{
    class Program
    {
        public class Manager
        {
            private string _strManagerFirstName;
            public string strManagerFirstName
            {
                set { _strManagerFirstName = value; }
                get { return _strManagerFirstName; }
            }

            private string _strManagerLastName;
            public string strManagerLastName
            {
                set { _strManagerLastName = value; }
                get { return _strManagerLastName; }
            }

            private int _intManagerAge;
            public int intManagerAge
            {
                set { _intManagerAge = value; }
                get { return _intManagerAge; }
            }

            private string _strManagerPhone;
            public string strManagerPhone
            {
                set { _strManagerPhone = value; }
                get { return _strManagerPhone; }
            }

            public void PrinManagerInfo()
            {
                Console.WriteLine("Menager : {0}  {1} (age :  {2}, phoneNumber :  {3})", strManagerFirstName, strManagerLastName, intManagerAge, strManagerPhone);
            }
        }

        public class CompanyInfo
        {
            private string _strCompanyName;
            public string strCompanyName
            {
                set { _strCompanyName = value; }
                get { return _strCompanyName; }
            }

            private string _strCompanyAddress;
            public string strCompanyAddress
            {
                set { _strCompanyAddress = value; }
                get { return _strCompanyAddress; }
            }

            private string _strCompanyPhone;
            public string strCompanyPhone
            {
                set { _strCompanyPhone = value; }
                get { return _strCompanyPhone; }
            }

            private string _strCompanyFax;
            public string strCompanyFax
            {
                set { _strCompanyFax = value; }
                get { return _strCompanyFax; }
            }

            private string _strCompanyWebSite;
            public string strCompanyWebSite
            {
                set { _strCompanyWebSite = value; }
                get { return _strCompanyWebSite; }
            }

            public void PrintCompanyInfo()
            {
               Console.WriteLine("{0} \n{1} \n{2} \n{3} \n{4} ", strCompanyName,strCompanyAddress, strCompanyPhone, strCompanyFax, strCompanyWebSite);
            }
        }


        static void Main(string[] args)
        {
            CompanyInfo ci = new CompanyInfo();
            ci.strCompanyName = "Telerik Academy";
            ci.strCompanyAddress = "231 Al. Malinov, Sofia ";
            ci.strCompanyPhone = "+359 888 55 55 555 ";
            ci.strCompanyFax = "N/A";
            ci.strCompanyWebSite = "http://telerikacademy.com/";

            Manager mngr = new Manager();
            mngr.strManagerFirstName = "Nikolay";
            mngr.strManagerLastName = "Kostov";
            mngr.intManagerAge = 25;
            mngr.strManagerPhone = "+359 2 981 981";

            ci.PrintCompanyInfo();
            mngr.PrinManagerInfo();
        }
    }
}
