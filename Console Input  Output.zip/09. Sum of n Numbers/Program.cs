﻿/*
Problem 9. Sum of n Numbers
• Write a program that enters a number  n  and after that enters more  n  numbers and calculates and prints their  sum . Note: You may need to use a for-loop. 

Examples:


numbers  sum

3        90 
20  
60  
10
 
5         6.5 
2  
-1  
-0.5  
4  
2  
 
1         1 
1 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09.Sum_of_n_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
           
            int intNumber,intSum=0;
            Console.Write("Please, enter the number of numbers to sum : ");
            intNumber = int.Parse(Console.ReadLine());

            for (int i = 1; i <= intNumber; i++)
            {
                intSum += int.Parse(Console.ReadLine());
            }

            Console.WriteLine("The sum is : {0}",intSum);
        }
    }
}
