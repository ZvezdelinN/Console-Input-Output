﻿/*
Problem 1. Sum of 3 Numbers
• Write a program that reads 3 real numbers from the console and prints their sum.

Examples:


a      b      c      sum

3      4      11     18 
-2     0       3      1 
5.5    4.5    20.1   30.1 
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01.Sum_of_Three_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            double dblFirstNumber;
            double dblSecondNumber;
            double dblThirdNumber;
            double dblSum;

            Console.Write("Please endter the first number : ");
            dblFirstNumber=double.Parse(Console.ReadLine());
            Console.Write("Please endter the first number : ");
            dblSecondNumber = double.Parse(Console.ReadLine());
            Console.Write("Please endter the first number : ");
            dblThirdNumber = double.Parse(Console.ReadLine());

            dblSum = dblFirstNumber + dblSecondNumber + dblThirdNumber;

            Console.WriteLine("The sum of {0} + {1} + {2} = {3}",dblFirstNumber,dblSecondNumber,dblThirdNumber,dblSum);
        }
    }
}
