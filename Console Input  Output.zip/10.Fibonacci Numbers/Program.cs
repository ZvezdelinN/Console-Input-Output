﻿/*
Problem 10. Fibonacci Numbers
• Write a program that reads a number  n  and prints on the console the first  n  members of the Fibonacci sequence (at a single line, separated by comma and space -  , ) :  0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, … .
F(n) = F(n-1) + F(n-2)
Note: You may need to learn how to use loops.

Examples:

n    comments


1    0 
3    0 1 1 
10   0 1 1 2 3 5 8 13 21 34 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10.Fibonacci_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int intNumber;
            int[] intArrayOfFibonaciiNumbers;
            string strNumber;
            Console.Write("Please, enter the number of Fibonacii's numbers to see : ");
            strNumber = Console.ReadLine();

            if(int.TryParse(strNumber, out intNumber))
            {
                if (Enumerable.Range(0,int.MaxValue).Contains(intNumber))
                {
                    intArrayOfFibonaciiNumbers = new int[intNumber + 1];


                    if (intNumber == 0)
                    {
                        intArrayOfFibonaciiNumbers[0] = 0;
                        Console.WriteLine(intArrayOfFibonaciiNumbers[0]);
                    }

                    else if (intNumber == 1)
                    {
                        intArrayOfFibonaciiNumbers[0] = 0;
                        intArrayOfFibonaciiNumbers[1] = 1;
                        Console.WriteLine("{0} {1}", intArrayOfFibonaciiNumbers[0], intArrayOfFibonaciiNumbers[1]);
                    }
                    else
                    {
                        intArrayOfFibonaciiNumbers[0] = 0;
                        intArrayOfFibonaciiNumbers[1] = 1;

                        for (int i = 2; i <= intNumber; i++)
                        {
                            intArrayOfFibonaciiNumbers[i] = intArrayOfFibonaciiNumbers[i - 1] + intArrayOfFibonaciiNumbers[i - 2];
                        }

                        foreach (int i in intArrayOfFibonaciiNumbers)
                        {
                            Console.Write("{0} ", i);
                        }
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("The number is under 0 or heigher than {1}", int.MaxValue.ToString());
                }
            }
            else
            {
                 Console.WriteLine("Uneble to convert string to int");
            }
           
        }
    }
}
