﻿/*
Problem 7. Sum of 5 Numbers
• Write a program that enters 5 numbers (given in a single line, separated by a space), calculates and prints their sum.

Examples:


numbers               sum

1 2 3 4 5             15 
10 10 10 10 10        50 
1.5 3.14 8.2 -1 0     11.84 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _07.Sum_of_5_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            string strNumber="";
            string[] strArrayOfNumbers;
            double[] dblArrayOfNumbers;
            double dblResult=0.0;

            strNumber = Console.ReadLine();

            strArrayOfNumbers = strNumber.Split(' ');
            dblArrayOfNumbers = new double[strArrayOfNumbers.Length];

            for (int i = 0; i < strArrayOfNumbers.Length; i++)
            {
                dblArrayOfNumbers[i] = double.Parse(strArrayOfNumbers[i]);
            }

            foreach(double dbl in dblArrayOfNumbers)
            {
                dblResult += dbl;
            }

            Console.WriteLine(dblResult);
        }
    }
}
