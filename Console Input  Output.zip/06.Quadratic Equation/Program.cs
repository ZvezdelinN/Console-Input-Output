﻿/*
Problem 6. Quadratic Equation
• Write a program that reads the coefficients  a ,  b  and  c  of a quadratic equation ax2 + bx + c = 0 and solves it (prints its real roots).

Examples:

 a    b    c    roots


 2    5    -3     x1=-3; x2=0.5 
-1    3     0     x1=3; x2=0 
-0.5  4    -8     x1=x2=4 
 5    2     8     no real roots 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06.Quadratic_Equation
{
    class Program
    {
        static void Main(string[] args)
        {
            double dblFirstNumber;
            double dblSecondNumber;
            double dblThirdNumber;
            double dblDiskriminanta;
            double dblX1;
            double dblX2;

            Console.Write("Please enter first number : ");
            dblFirstNumber = double.Parse(Console.ReadLine());

            Console.Write("Please enter second number : ");
            dblSecondNumber = double.Parse(Console.ReadLine());

            Console.Write("Please enter third number : ");
            dblThirdNumber = double.Parse(Console.ReadLine());

            dblDiskriminanta = Math.Pow(dblSecondNumber, 2) - (4 * dblFirstNumber * dblThirdNumber);

            if (dblDiskriminanta < 0)
                Console.WriteLine("There are no real roots");
            else if(dblDiskriminanta == 0)
            {
                dblX1 = -(dblSecondNumber) / (2 * dblFirstNumber);
                Console.WriteLine("There is only one root and x1 = x2 = {0}",dblX1);
            }
            else if(dblDiskriminanta > 0)
            {
                dblX1 = (-(dblSecondNumber) + Math.Sqrt(dblDiskriminanta)) / (2 * dblFirstNumber);
                dblX2 = (-(dblSecondNumber) - Math.Sqrt(dblDiskriminanta)) / (2 * dblFirstNumber);
                Console.WriteLine("There are two roots and x1 = {0:F2}, x2 = {1:F2}", dblX1,dblX2);
            }
            
        }
    }
}
