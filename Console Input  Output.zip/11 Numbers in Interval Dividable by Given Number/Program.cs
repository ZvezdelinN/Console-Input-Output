﻿/*
Problem 11.* Numbers in Interval Dividable by Given Number
• Write a program that reads two positive integer numbers and prints how many numbers  p  exist between them such that the reminder of the division by  5  is  0 .

Examples:


start    end      p         comments


17       25       2         20, 25 
5        30       6         5, 10, 15, 20, 25, 30 
3        33       6         5, 10, 15, 20, 25, 30 
3         4       0         - 
99      120       5         100, 105, 110, 115, 120 
107     196      18         110, 115, 120, 125, 130, 135, 140, 145, 150, 155, 160, 165, 170, 175, 180, 185, 190, 195 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11_Numbers_in_Interval_Dividable_by_Given_Number
{
    class Program
    {
        static void Main(string[] args)
        {
            int intStart;
            int intFinish;
            int intCounter;
            int intIncreaser=0;

            Console.Write("Please , enter start number : ");
            intStart = int.Parse(Console.ReadLine());

            Console.Write("Please , enter finish number : ");
            intFinish = int.Parse(Console.ReadLine());

            Console.Write("Please , enter the number of the numbers that are devided by 5 : ");
            intCounter = int.Parse(Console.ReadLine());


            for(int i=intStart;i<=intFinish;i++)
            {
                if (intIncreaser <= intCounter)
                {
                    if (i % 5 == 0)
                    {
                        Console.Write("{0} ,",i);
                        intIncreaser += 1;
                    }
                }
            }
        }
    }
}
